package practise;

public enum Logs {
LOG_ON,
LOG_OFF
}
