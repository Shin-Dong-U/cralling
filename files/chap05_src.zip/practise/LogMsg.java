package practise;

import java.util.Scanner;

public class LogMsg {
	public static void main(String[] args) {
		boolean runflag = true ;
		Logs log = null ;
		String logStatus = null ;
        while(runflag) {
        	Scanner scanner = new Scanner(System.in);
        	String inputString = scanner.next();
        	switch (inputString) {
        		case "1":
        			log = Logs.LOG_ON;
        			logStatus = log.name();
        			System.out.println(logStatus);
        			break ;
        		case "2":
        			log = Logs.LOG_OFF;
        			logStatus = log.name();
        			System.out.println(logStatus);
        			break ;
			}
        	if (inputString.equals("3")) {
        		runflag = false ;
        	}
		};
		System.out.println();
		System.out.println("프로그램 종료");
	}
}
