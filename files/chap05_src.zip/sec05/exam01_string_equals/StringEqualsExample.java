﻿package sec05.exam01_string_equals;
public class StringEqualsExample {
	public static void main(String[] args) {	
		
		int[] intVar1 = null;
		int[] intVar2 = null;
		
		System.out.println(intVar1);
		//System.out.println(intVar1[0]);//없는 인덱스의 값을 읽어들이려고 할 때.
		
		
		intVar1 = new int[5] ;
		
		System.out.println(intVar1[0]);
		
		
		System.out.println("1=====================");
		
		String[] strVar1 = null;
		String[] strVar2 = null;
		
		System.out.println(strVar1);
		
		//strVar1[0] = "신상현";  
		//strVar2[0] = "신상현";
		
		if(strVar1 == strVar2) {
			System.out.println("strVar1과 strVar2는 참조가 같음");
		} else {
			System.out.println("strVar1과 strVar2는 참조가 다름");
		}
		System.out.println("2=====================");
		
		strVar1 = new String[] {null};
		strVar2 = new String[] {"신상현"};
		
		System.out.println(strVar2[0]);
		System.out.println(strVar1[0]);
		
		System.out.println("3=====================");
		if(strVar1[0] == strVar2[0]) {
			System.out.println("strVar1[0]과 strVar2[0]는 참조가 같음");
		} else {
			System.out.println("strVar1[0]과 strVar2[0]는 참조가 다름");
		}
		System.out.println("4=====================");
		System.out.println("4=====================");
		
		if(strVar1[0].equals(strVar2[3])) {
			System.out.println("strVar1과 strVar2는 문자열이  같음");
		}

		
		System.out.println("5=====================");
		
		String strVar3 = new String("신민철");
		String strVar4 = new String("신민철");
		
		if(strVar3 == strVar4) {
			System.out.println("strVar3과 strVar4는 참조가 같음");
		} else {
			System.out.println("strVar3과 strVar4는 참조가 다름");
		}
		
		if(strVar3.equals(strVar4)) {
			System.out.println("strVar3과 strVar4는 문자열이  같음");
		}		
	} 
}
