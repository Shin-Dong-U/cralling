package sec07.exam01_enum;

public enum Weeks {
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	TURSDAY,
	FRIDAY,
	SATERDAY,
	SUNDAY
}
